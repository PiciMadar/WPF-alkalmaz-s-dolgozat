﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace VendoDolgozatRD
{
    /// <summary>
    /// Interaction logic for NameCardWindow.xaml
    /// </summary>
    public partial class NameCardWindow : Window
    {
        public NameCardWindow(string nevS, string szulD, string telSz, string eMail)
        {
            InitializeComponent();
            TextBlockFeltoltes(nevS,szulD,telSz,eMail);
        }

        private void TextBlockFeltoltes(string nevS, string szulD, string telSz, string eMail)
        {
            cardName.Text = nevS;
            cardBirthDate.Text = szulD;
            cardPhoneNumber.Text = telSz;
            cardEmail.Text = eMail;
        }
    }
}
