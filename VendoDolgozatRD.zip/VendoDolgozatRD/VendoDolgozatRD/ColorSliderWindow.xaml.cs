﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace VendoDolgozatRD
{
    /// <summary>
    /// Interaction logic for ColorSliderWindow.xaml
    /// </summary>
    public partial class ColorSliderWindow : Window
    {
        public ColorSliderWindow()
        {
            InitializeComponent();
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            byte red1 = (byte)rSlider.Value;
            byte green1 = (byte)gSlider.Value;
            byte blue1 = (byte)bSlider.Value;

            PanelColorChange(red1,green1,blue1);
            TextColorChange(red1,green1,blue1);
        }

        private void TextColorChange(byte red1, byte green1, byte blue1)
        {
            byte r2 = (byte)(255 - red1);
            byte g2 = (byte)(255 - green1);
            byte b2 = (byte)(255 - blue1);
            Caption.Foreground = new SolidColorBrush(Color.FromRgb(r2,g2,b2));
        }

        private void PanelColorChange(byte red1, byte green1, byte blue1)
        {
            MainGrid.Background = new SolidColorBrush(Color.FromRgb(red1,green1,blue1));
        }
    }
}
